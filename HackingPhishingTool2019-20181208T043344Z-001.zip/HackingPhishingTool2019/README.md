# Akhil Hacker powered by Phishing Tool
## Author: github.com/posaveeram
Phishing Tool for Instagram, Facebook, Twitter, Snapchat, Github, Yahoo, Protonmail, Google, Spotify, Netflix, Linkedin, Wordpress, Origin, Steam, Microsoft, InstaFollowers, Pinterest +1 customizable
### Features:
### Port Forwarding using Ngrok or Serveo

## Legal disclaimer:

Usage of Shellphish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 
this is for educational purpose only guys...
dont misuse this 
join us Whatsapp @Cyber Security White Hat @Unlimited
join us Telegram in the name of Hack Store



### Usage:
```
git clone https://github.com/posaveeram/powerfulphishingtool2019
cd akhilhacker
bash phishingtool.sh
```

